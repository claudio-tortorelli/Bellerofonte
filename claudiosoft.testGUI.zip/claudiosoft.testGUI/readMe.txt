--------------------------------
TestGUI v. 1.0 brief description
--------------------------------

TestGUI is a Graphical User Interface of Bellerofonte testing tool. It's is a specific type test GUI, oriented to Installation Tests. It need a Bellerofonte installation first and a Java SDK 1.4 or upper.
It was created as test for Orbilio's platform (http://then.dsi.unifi.it) but you can change this destination. testGUI simply try to reach (with a deep visit) some pages of a site and report if all are reachable.

HowTo change the list of files
------------------------------

You can change the list of files that Bellerofonte try to reach in the file /claudiosoft.TestGUI/files/listFiles.txt. You must write the RELATIVE URL of these pages (without host address). One URL per line.

If you use testGUI to test Orbilio you can let this list unchanged.


HowTo start TestGUI
-------------------

Once you have personalized the list with your files's url, you can start testGUI interface with the bin file /claudiosoft.TestGUI/bin/testGUI.bat

HowTo complete the form
-----------------------

In the window that you see you must fill four fields:
- the Url of the dir that hold your index file (Bellerofonte try to start its test from here and append to it the relative Urls of listFiles.txt)
- the ABSOLUTE path of your Bellerofonte installation's main dir.
- the admin username (if in you index there is a login form)
- the admin password (if in you index there is a login form)

There is also a customizable textarea with all file that testGUI try to reach, but you can let this area unchanged if you have edited listFiles.txt first.

HowTo start the test
--------------------

Simply: click on Start button. A window with the report will open without display nothing until the elaboration will be end. You can watch at Bellerofonte output clicking on console window that is open on the back. 
testGUI say you how the test is finished with a text area in the bottom of window. If nothing result appear, maybe was be a general error during the computation. You try to check the console window to verify also the Bellerofonte's output.

if you don't test Orbilio
-------------------------

Perhaps you need of some manual correction of testGUI: by default it start two separate test of deep visit (with deep 1), one before the login and one after the login. If your site don't have a login form in the first page you must change the code of testGUI manually. After you have learn about Bellerofonte, you can watch at /claudiosoft.testGUI/src/Start.java, specially for "createFileTest" method.

CopyRight
---------

This example of interface for Bellerofonte is right-free. You can modify it to create a more complex interface for your tests.





