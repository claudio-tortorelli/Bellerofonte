package orbilio.webTest.InstallationTest;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Exit implements ActionListener
{
	public Exit()
	{		
	}
	
	public void actionPerformed(ActionEvent e)
	{
		System.out.println ("Bye bye!");
		System.exit(0);
	}
};