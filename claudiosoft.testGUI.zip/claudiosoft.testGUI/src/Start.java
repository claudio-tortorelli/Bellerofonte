package orbilio.webTest.InstallationTest;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.net.*;
import java.io.*;

public class Start implements ActionListener
{

/**
 * Fields
 */
 	TestGUI gui;
	
/**
 * Constructor
 *
 * It take the gui frame in input to get informations
 * and update results
 */
	public Start(TestGUI g)
	{		
		gui = g;
	}

/**
 * Get values from gui's form
 */
	public Vector getFormValues()
	{
		Vector res = new Vector();
		res = gui.returnFormValue();
		return res;
	}

/**
 * Make action after read the form: it do all operations
 * needed to execute Bellerofonte in a installation test.
 * If the form is incomplete it don't proceed.
 */
 	public void actionPerformed(ActionEvent e)
	{
	// get values from form
		Vector values = getFormValues();
	// assign these values to local variables
		String url = (String)values.elementAt(0);
		String path = (String)values.elementAt(1);
		String id = (String)values.elementAt(2);
		String pw = (String)values.elementAt(3);
		String list = (String)values.elementAt(4);
	// check if nothing field is empty
		boolean allOk = true;
		for (int i = 0; i < values.size(); i++)
		{
			if (((String)values.elementAt(i)).equals(""))
			{
				gui.writeMessage(" - ATTENTION: All fields must be compiled ! -");
				allOk = false;
			}			
		}
	// check if url of Orbilio ends with '/'	
		if (url.charAt(url.length()-1) != '/')
		{
			url = url + '/';
		}		
	// if all fields are filled	
		if (allOk)
		{
			if (createOptionsFile(url,path))
			{
				if (createFileWithNames(url,list))
				{
					if (createFileTest(id,pw,path))
					{
						launchBellerofonte(path);
					}
				}
			}
		}
	}

/**
 * From the absolute url of Orbilio on the server,
 * it extracts the protocol, the host, the path and
 * the filename. With these values it builds the 
 * options file for the test.
 */	
	public boolean createOptionsFile(String url, String pathBel)
	{
		String protocol = "";
		String host = "";
		String path = "";
		//String fileName = "";
		boolean urlOk = true;
		try 
		{
			URL u = new URL(url);
			protocol = u.getProtocol();
			host = u.getHost();
			path = u.getPath();
			//fileName = u.getFile();			
		}
	// if the url is invalid
		catch (MalformedURLException e)
		{
			gui.writeMessage("MAYBE THE URL OF ORBILIO IS MALFORMED. Check it.");
			urlOk = false;
			return false;
		}
	// if url has been correctly processed 
		if (urlOk)
		{		
			Properties props = new Properties(); 		
			try
			{
			// open the skeleton file options
				File tmp = new File (TestGUI.dirFile + "opt.txt");									
			// open the specific test file options that will be deleted after test
				File tmp1 = new File (pathBel+File.separatorChar +"webtestfiles"+ File.separatorChar+"options"+File.separatorChar+"_opt1_.txt");									
				tmp1.deleteOnExit();	
		
				if (tmp.exists())
				{
				// open streams and update some selected key
					FileInputStream fis = new FileInputStream(tmp);
					DataInputStream dfis = new DataInputStream(fis);						
					FileOutputStream fos = new FileOutputStream(tmp1);					
					props.load(dfis);					
					props.setProperty("protocol", protocol);					
					props.setProperty("host", host);					
					props.setProperty("path", path);					
					props.store(fos,"InstallationTestOption");
					fis.close();
					dfis.close();										
					fos.close();									
				}			
				else
				{
					gui.writeMessage("IMPOSSIBLE TO FIND opt.txt IN \\files OF TESTGUI.\nCheck if it's available.");
					return false;
				}
			}
			catch (IOException e)
			{
				gui.writeMessage("I/O EXCEPTION: check if \\files in TestGUI and \\options in Bellerofonte are availables \nor if Bellerofonte's root path is correct.");
				return false;
			}		
		}		
		return true;
	}
	
/**
 * After reads from the list of files to reach, it
 * build a text file that hold the list. The
 * file will be used in the ReachAll test.
 */
	public boolean createFileWithNames(String url, String list)
	{
	// create the files that hold the name of files to reach. It will be deleted after test
		File tmp = new File(TestGUI.dirFile + "listFile1.txt");
		tmp.deleteOnExit();
		File tmp2 = new File(TestGUI.dirFile + "listFileAdmin.txt");
		tmp2.deleteOnExit();
		try
		{		
		// open streams
			FileOutputStream testList = new FileOutputStream(tmp);
			DataOutputStream testListOut = new DataOutputStream(testList);							
			FileOutputStream testListAdm = new FileOutputStream(tmp2);
			DataOutputStream testListOutAdm = new DataOutputStream(testListAdm);							
		// extract single names and write them to file adding the base url as prefix
			int i = 0;
			int j = 0;		
			if (list.charAt(list.length()-1) != '\n')	// if there isn't final return			
			{
				list = list + '\n';					
			}			
			String s = "";
			while (i < list.length())
			{
			// if is end the url
				if (list.charAt(i) == '\n')
				{
				// select if it must be write on admin list
					s = url+list.substring(j,i+1);
					if (s.indexOf("/admin") == -1)
					{
						testListOut.writeBytes(s);
					}			
					else
					{
						testListOutAdm.writeBytes(s);
					}		
					j = i+1;
				}
				i++;
			}
		// add last name
			s = list.substring(j,i);
			if (s.indexOf("/admin") == -1)
			{
				testListOut.writeBytes(s);
			}
			else
			{
				testListOutAdm.writeBytes(s);
			}
		// close streams
			testListOut.close();		
			testList.close();				
			testListOutAdm.close();		
			testListAdm.close();				
		}
		catch (IOException e)
		{
			gui.writeMessage("I/O EXCEPTION ON WRITING THE NAME LIST OF FILES:\ncheck if the \\files directory in TestGUI is available");
			return false;
		}				
		return true;				
	}
	
/**
 * It make a file test (.txt) that, from the index
 * page, make the login and then launch the ReachAll
 * test. ReachAll needs of file list name and path,
 * of the depth of visit (2 by default) and of the
 * timeout (2 sec by default).
 *
 * ATTENTION: this method will be valid only if the
 * names of field in the login form of Orbilio remains
 * the same.
 */
	public boolean createFileTest(String id, String pw, String pathBel)
	{
	// reopen listFile1.txt and listFileAdm.txt to get their absolute path
		File lf = new File(TestGUI.dirFile + "listFile1.txt");
		String absPath = lf.getAbsolutePath();
		File lf2 = new File(TestGUI.dirFile + "listFileAdmin.txt");
		String absPath2 = lf2.getAbsolutePath();
	
	// create the file test. It will be deleted after test
		File tmp = new File(pathBel+File.separatorChar +"webtestfiles"+ File.separatorChar+"testTXT"+File.separatorChar+"_InstallTest_.txt");
		tmp.deleteOnExit();
		try
		{		
			tmp.createNewFile();	
		// open streams
			FileOutputStream test = new FileOutputStream(tmp);
			DataOutputStream testOut = new DataOutputStream(test);							
		// extract single names and write them to file
			testOut.writeBytes("SetFormContent|0|uname|"+ id + "|\n");
			testOut.writeBytes("SetFormContent|0|pass|"+ pw + "|\n");
			testOut.writeBytes("SubmitForm|0||\n");
			testOut.writeBytes("CheckLink|Admin||\n");
			testOut.writeBytes("ReachAll|"+absPath+"|1|1500|\n");				
			testOut.writeBytes("FollowLinks|string|Admin|\n");
			testOut.writeBytes("ReachAll|"+absPath2+"|0|1500|");				
			
		// close streams
			testOut.close();		
			test.close();				
		}
		catch (IOException e)
		{
			gui.writeMessage("I/O EXCEPTION ON WRITING THE TEST FILE:\ncheck the Bellerofonte's root path or if \\testTXT in Bellerofonte is available.");
			return false;
		}		
		return true;						
	}
	
/**
 * This method read the path where is Bellerofonte's
 * binary and then launch it with the needed parameters.
 *
 * It open a window where it prompt the output and 
 * update the result area of the gui with the test
 * result.
 */
	public void launchBellerofonte(String pathBel)
	{
		try
		{	
		// open a frame to display the report...			
			JTextArea t = new JTextArea ();
			t.setText("Waiting some seconds until the elaboration...\n\n");
			t.setVisible(true);
			JScrollPane jsp = new JScrollPane(t);					
			jsp.setVisible(true);
			jsp.show(true);
			jsp.setSize(340,300);
			JFrame jf = new JFrame();
			jf.setSize(350,300);
			jf.setLocation(270,50);
			jf.setTitle("Elaborating...");
			jf.show(true);
			jf.setVisible(true);
			jf.getContentPane().add(jsp);
			jf.repaint();			
		
		// create a separate process with the command to execute Bellerofonte
			Runtime rt = Runtime.getRuntime();    									
			String tmpStr = "cmd /c java -cp "+pathBel + " -jar "+pathBel+File.separatorChar+"lib"+File.separatorChar+"bellerofonte.jar"+" " + "_opt1_.txt" + " " + "_InstallTest_.txt" + " " + "ResultInstallTest.txt";			
			Process process = rt.exec(tmpStr);									
			
		// display output on the screen	and get info on the results
			InputStreamReader reader =             
			  new InputStreamReader( process.getInputStream() );
			
			BufferedReader bufReader =
			    new BufferedReader(reader );       
			                                  
			String line;
			while ((line = bufReader.readLine()) != null)
			{
				System.out.println(line); 
			}
			        
		// if there aren't exceptions it update GUI with result
		// and display the report
			int exitRes = process.exitValue();			
			File rep = new File(pathBel+File.separatorChar+"webtestfiles"+File.separatorChar+"reports"+File.separatorChar+"ResultInstallTest.txt");
			FileInputStream fis = new FileInputStream(rep);
			DataInputStream dfis = new DataInputStream(fis);						
			String repBuf = dfis.readLine();
			while (repBuf != null)
			{
				t.append(repBuf+"\n");
				repBuf = dfis.readLine();
			}
			switch (exitRes)
			{
				case 0: gui.writeResult("Good! All file are actives and reachables.");					
					break;				
				case 1: gui.writeResult("Bad! At least one file isn't reachable. Check the report.");
					break;
				case 2: gui.writeResult("There have been some errors. Check the report.");
					break;
			}
		} 
		catch(IOException e)
		{ 
			gui.writeMessage("I/O EXCEPTION ON EXECUTING BELLEROFONTE");
		}
	}
};