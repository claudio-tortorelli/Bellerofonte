package orbilio.webTest.InstallationTest;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import jui.layout.HorizontalNode;
import jui.layout.VerticalNode;
import jui.layout.ComponentNode;
import jui.layout.ComponentNodeInfo;
import jui.layout.SpacingNode;
import jui.layout.BoxTreeLayout;
import java.util.*;
import java.io.*;

public class TestGUI extends JPanel 
{
	
/** 
 * FIELDS
 */
	private JLabel title;
	private JLabel initmsg1;
	private JLabel msgInit2;
	private JLabel ask1;
	private JTextField field1;
	private JLabel ask2;
	private JTextField field2;
	private JLabel ask3;
	private JTextField field3;
	private JLabel ask4;
	private JTextField field4;
	private JLabel fileToReach;
	private JScrollPane listOfFiles;
	private JLabel resultTitle;
	private JTextArea result;
	private JButton bExit;
	private JButton bStart;
	// private Image imageBel;
	
	static String dirImg = "images" + File.separatorChar;
	static String dirFile = "files" + File.separatorChar;

/**
 * Constructor
 */
	public TestGUI() 
	{
		initTitle();
		add(title);
		initInitmsg1();
		add(initmsg1);
		initMsgInit2();
		add(msgInit2);
		initAsk1();
		add(ask1);
		initField1();
		add(field1);
		initAsk2();
		add(ask2);
		initField2();
		add(field2);
		initAsk3();
		add(ask3);
		initField3();
		add(field3);
		initAsk4();
		add(ask4);
		initField4();
		add(field4);
		initFileToReach();
		add(fileToReach);
		initListOfFiles();
		add(listOfFiles);
		initResultTitle();
		add(resultTitle);
		initResult();
		add(result);
		initBExit();
		add(bExit);
		initBStart();
		add(bStart);
		setLayout(new BoxTreeLayout(new VerticalNode(new VerticalNode(new HorizontalNode(new ComponentNode(title, new Insets(13, 13, 7, 0), new ComponentNodeInfo(true, true)), new SpacingNode(new Dimension(131, 41))), new VerticalNode(new HorizontalNode(new ComponentNode(initmsg1, new Insets(0, 13, 7, 0), new ComponentNodeInfo(true, true)), new SpacingNode(new Dimension(147, 25))), new VerticalNode(new HorizontalNode(new ComponentNode(msgInit2, new Insets(0, 13, 0, 0), new ComponentNodeInfo(true, true)), new SpacingNode(new Dimension(152, 16))), new SpacingNode(new Dimension(493, 15))))), new VerticalNode(new HorizontalNode(new ComponentNode(ask1, new Insets(0, 13, 7, 7), new ComponentNodeInfo(true, true)), new HorizontalNode(new ComponentNode(field1, new Insets(0, 0, 7, 0), new ComponentNodeInfo(true, true)), new SpacingNode(new Dimension(40, 31)))), new VerticalNode(new HorizontalNode(new ComponentNode(ask2, new Insets(0, 13, 7, 7), new ComponentNodeInfo(true, true)), new HorizontalNode(new ComponentNode(field2, new Insets(0, 0, 7, 0), new ComponentNodeInfo(true, true)), new SpacingNode(new Dimension(40, 31)))), new VerticalNode(new HorizontalNode(new ComponentNode(ask3, new Insets(0, 13, 7, 7), new ComponentNodeInfo(true, true)), new HorizontalNode(new ComponentNode(field3, new Insets(0, 0, 7, 0), new ComponentNodeInfo(true, true)), new SpacingNode(new Dimension(40, 30)))), new VerticalNode(new HorizontalNode(new ComponentNode(ask4, new Insets(0, 13, 13, 7), new ComponentNodeInfo(true, true)), new HorizontalNode(new ComponentNode(field4, new Insets(0, 0, 10, 0), new ComponentNodeInfo(true, true)), new SpacingNode(new Dimension(40, 33)))), new VerticalNode(new VerticalNode(new VerticalNode(new VerticalNode(new HorizontalNode(new ComponentNode(fileToReach, new Insets(0, 13, 7, 0), new ComponentNodeInfo(true, true)), new SpacingNode(new Dimension(145, 27))), new HorizontalNode(new ComponentNode(listOfFiles, new Insets(0, 13, 7, 0), new ComponentNodeInfo(true, true)), new SpacingNode(new Dimension(40, 95)))), new HorizontalNode(new ComponentNode(resultTitle, new Insets(0, 13, 7, 0), new ComponentNodeInfo(true, true)), new SpacingNode(new Dimension(287, 25)))), new VerticalNode(new HorizontalNode(new ComponentNode(result, new Insets(0, 13, 0, 0), new ComponentNodeInfo(true, true)), new SpacingNode(new Dimension(40, 43))), new SpacingNode(new Dimension(493, 18)))), new HorizontalNode(new HorizontalNode(new ComponentNode(bExit, new Insets(0, 13, 1, 0), new ComponentNodeInfo(true, true)), new SpacingNode(new Dimension(262, 32))), new HorizontalNode(new ComponentNode(bStart, new Insets(0, 0, 1, 0), new ComponentNodeInfo(true, true)), new SpacingNode(new Dimension(40, 32))))))))))));
		revalidate();
	}

/**
 * It create a component before its inclusion in the gui
 */
	private void initTitle() 
	{			
		Icon ico = new ImageIcon(dirImg + "campus.png");		
		
		this.title = new JLabel();
		title.setName("title");
		title.setToolTipText(null);
		title.setIcon(ico);
		title.setText("Orbilio's Installation Test - v. 1.0");
		title.setFont(new Font("Verdana Grassetto", Font.BOLD, 16));		
		title.setEnabled(true);
		title.setVerticalAlignment(JLabel.CENTER);
		title.setHorizontalAlignment(JLabel.LEADING);
		title.setVerticalTextPosition(JLabel.CENTER);
		title.setHorizontalTextPosition(JLabel.TRAILING);
		title.setRequestFocusEnabled(true);
		title.setMinimumSize(new Dimension(223, 20));
		title.setMaximumSize(new Dimension(2147483647, 2147483647));
		title.setPreferredSize(new Dimension(319, 21));
	}

/**
 * It create a component before its inclusion in the gui
 */	
	private void initInitmsg1() 
	{
		this.initmsg1 = new JLabel();
		initmsg1.setName("initmsg1");
		initmsg1.setToolTipText(null);
		initmsg1.setText("Welcome in the installation test of your Orbilio platform! This test need a Bellerofonte's installation.");
		initmsg1.setFont(new Font("dialog",Font.PLAIN,12));
		initmsg1.setForeground(new Color(0, 0, 0, 255));
		initmsg1.setEnabled(true);
		initmsg1.setVerticalAlignment(JLabel.CENTER);
		initmsg1.setHorizontalAlignment(JLabel.LEADING);
		initmsg1.setVerticalTextPosition(JLabel.CENTER);
		initmsg1.setHorizontalTextPosition(JLabel.TRAILING);
		initmsg1.setRequestFocusEnabled(true);
		initmsg1.setMinimumSize(null);
		initmsg1.setMaximumSize(new Dimension(2147483647, 2147483647));
		initmsg1.setPreferredSize(new Dimension(303, 18));
	}
	
/**
 * It create a component before its inclusion in the gui
 */
	private void initMsgInit2() 
	{					
		this.msgInit2 = new JLabel();
		msgInit2.setName("msgInit2");
		msgInit2.setToolTipText(null);				
		msgInit2.setText("ATTENTION: this test need a Bellerofonte's installation.");
		msgInit2.setFont(new Font("dialog",Font.PLAIN, 12));
		msgInit2.setForeground(new Color(0, 0, 0, 255));
		msgInit2.setEnabled(true);
		msgInit2.setVerticalAlignment(JLabel.CENTER);
		msgInit2.setHorizontalAlignment(JLabel.LEADING);
		msgInit2.setVerticalTextPosition(JLabel.CENTER);
		msgInit2.setHorizontalTextPosition(JLabel.TRAILING);
		msgInit2.setRequestFocusEnabled(true);
		msgInit2.setMinimumSize(null);
		msgInit2.setMaximumSize(new Dimension(2147483647, 2147483647));
		msgInit2.setPreferredSize(null);
		msgInit2.setVisible(false);
	}
	
/**
 * It create a component before its inclusion in the gui
 */
	private void initAsk1() 
	{
		this.ask1 = new JLabel();
		ask1.setName("ask1");
		ask1.setToolTipText(null);
		ask1.setText("Enter the absolute URL of Orbilio's index file ");
		ask1.setFont(new Font("dialog.bold", Font.BOLD, 12));
		ask1.setForeground(new Color(0, 0, 0, 255));
		ask1.setEnabled(true);
		ask1.setVerticalAlignment(JLabel.CENTER);
		ask1.setHorizontalAlignment(JLabel.RIGHT);
		ask1.setVerticalTextPosition(JLabel.CENTER);
		ask1.setHorizontalTextPosition(JLabel.TRAILING);
		ask1.setRequestFocusEnabled(true);
		ask1.setMinimumSize(new Dimension(181, 16));
		ask1.setMaximumSize(new Dimension(2147483647, 2147483647));
		ask1.setPreferredSize(new Dimension(267, 24));
	}

/**
 * It create a component before its inclusion in the gui
 */
	private void initField1() 
	{
		this.field1 = new JTextField();
		field1.setName("field1");
		field1.setToolTipText("This field must be filled with the URL of Orbilio's index.php");
		field1.setText("http://localhost/");
		field1.setDragEnabled(false);
		field1.setEnabled(true);
		field1.setRequestFocusEnabled(true);
		field1.setMinimumSize(null);
		field1.setMaximumSize(null);
		field1.setPreferredSize(new Dimension(136, 24));
	}

/**
 * It create a component before its inclusion in the gui
 */
	private void initAsk2() 
	{
		this.ask2 = new JLabel();
		ask2.setName("ask2");
		ask2.setToolTipText(null);
		ask2.setText("Enter the absolute path of Bellerofonte's root dir");
		ask2.setFont(new Font("dialog.bold", Font.BOLD, 12));
		ask2.setForeground(new Color(0, 0, 0, 255));
		ask2.setEnabled(true);
		ask2.setVerticalAlignment(JLabel.CENTER);
		ask2.setHorizontalAlignment(JLabel.RIGHT);
		ask2.setVerticalTextPosition(JLabel.CENTER);
		ask2.setHorizontalTextPosition(JLabel.TRAILING);
		ask2.setRequestFocusEnabled(true);
		ask2.setMinimumSize(new Dimension(251, 16));
		ask2.setMaximumSize(new Dimension(2147483647, 2147483647));
		ask2.setPreferredSize(new Dimension(267, 24));
	}

/**
 * It create a component before its inclusion in the gui
 */
	private void initField2() 
	{
		String defStr = "C:"+File.separatorChar+"claudiosoft.bellerofonte";
		this.field2 = new JTextField();
		field2.setName("field2");
		field2.setToolTipText("This field must be filled with the absolute path of belJar.bat in your hard disk");
		field2.setText(defStr);
		field2.setDragEnabled(false);
		field2.setEnabled(true);
		field2.setRequestFocusEnabled(true);
		field2.setMinimumSize(null);
		field2.setMaximumSize(null);
		field2.setPreferredSize(new Dimension(136, 24));
	}

/**
 * It create a component before its inclusion in the gui
 */
	private void initAsk3() 
	{
		this.ask3 = new JLabel();
		ask3.setName("ask3");
		ask3.setToolTipText(null);
		ask3.setText("Enter the Orbilio's root ID");
		ask3.setFont(new Font("dialog.bold", Font.BOLD, 12));
		ask3.setForeground(new Color(0, 0, 0, 255));
		ask3.setEnabled(true);
		ask3.setVerticalAlignment(JLabel.CENTER);
		ask3.setHorizontalAlignment(JLabel.RIGHT);
		ask3.setVerticalTextPosition(JLabel.CENTER);
		ask3.setHorizontalTextPosition(JLabel.TRAILING);
		ask3.setRequestFocusEnabled(true);
		ask3.setMinimumSize(new Dimension(157, 16));
		ask3.setMaximumSize(new Dimension(2147483647, 2147483647));
		ask3.setPreferredSize(new Dimension(267, 23));
	}

/**
 * It create a component before its inclusion in the gui
 */
	private void initField3() 
	{
		this.field3 = new JTextField();
		field3.setName("field3");
		field3.setToolTipText("This field must be filled with the ID that you have choose to enter in Orbilio as root ");
		field3.setText("");
		field3.setDragEnabled(false);
		field3.setEnabled(true);
		field3.setRequestFocusEnabled(true);
		field3.setMinimumSize(null);
		field3.setMaximumSize(null);
		field3.setPreferredSize(new Dimension(136, 23));
	}

/**
 * It create a component before its inclusion in the gui
 */
	private void initAsk4() 
	{
		this.ask4 = new JLabel();
		ask4.setName("ask4");
		ask4.setToolTipText(null);
		ask4.setText("Enter the Orbilio's root password");
		ask4.setFont(new Font("dialog.bold", Font.BOLD, 12));
		ask4.setForeground(new Color(0, 0, 0, 255));
		ask4.setEnabled(true);
		ask4.setVerticalAlignment(JLabel.CENTER);
		ask4.setHorizontalAlignment(JLabel.RIGHT);
		ask4.setVerticalTextPosition(JLabel.CENTER);
		ask4.setHorizontalTextPosition(JLabel.TRAILING);
		ask4.setRequestFocusEnabled(true);
		ask4.setMinimumSize(null);
		ask4.setMaximumSize(new Dimension(2147483647, 2147483647));
		ask4.setPreferredSize(new Dimension(267, 20));
	}

/**
 * It create a component before its inclusion in the gui
 */
	private void initField4() 
	{
		this.field4 = new JTextField();
		field4.setName("field4");
		field4.setToolTipText("This field must be filled with the password that you have choose to enter in Orbilio as root ");
		field4.setText("");
		field4.setDragEnabled(false);
		field4.setEnabled(true);
		field4.setRequestFocusEnabled(true);
		field4.setMinimumSize(null);
		field4.setMaximumSize(null);
		field4.setPreferredSize(new Dimension(136, 23));
	}

/**
 * It create a component before its inclusion in the gui
 */
	private void initFileToReach() 
	{
		this.fileToReach = new JLabel();
		fileToReach.setName("fileToReach");
		fileToReach.setToolTipText(null);
		fileToReach.setText("Follow there is the list of the file that I will try to reach");
		fileToReach.setFont(new Font("dialog.bold", Font.BOLD, 12));
		fileToReach.setForeground(new Color(0, 0, 0, 255));
		fileToReach.setEnabled(true);
		fileToReach.setVerticalAlignment(JLabel.CENTER);
		fileToReach.setHorizontalAlignment(JLabel.LEADING);
		fileToReach.setVerticalTextPosition(JLabel.CENTER);
		fileToReach.setHorizontalTextPosition(JLabel.TRAILING);
		fileToReach.setRequestFocusEnabled(true);
		fileToReach.setMinimumSize(null);
		fileToReach.setMaximumSize(new Dimension(2147483647, 2147483647));
		fileToReach.setPreferredSize(new Dimension(305, 20));
	}

/**
 * It create a component before its inclusion in the gui
 */
	private void initListOfFiles() 
	{
	// get the standard list of file to reach from a file
		Vector listF = readFileTXT("listFile.txt");
	// this is the base list of file in the version 1.0
		JTextArea list = new JTextArea();	
		list.setToolTipText("This is the list of standard Orbilio's files. You can add new file manually but don't modify it if you don't know how!");							
		list.setName("list");
	// insert the files readed in the text area
		for (int i = 0; i < listF.size(); i++)
		{
			list.append((String)listF.elementAt(i)+"\n");		
		}

	// add the list to the scroll panel			
		this.listOfFiles = new JScrollPane(list);
		
		listOfFiles.setName("listOfFiles");		
		listOfFiles.setEnabled(true);			
		listOfFiles.setRequestFocusEnabled(true);
		listOfFiles.setMinimumSize(new Dimension(20, 20));
		listOfFiles.setMaximumSize(new Dimension(2147483647, 2147483647));		
		listOfFiles.setPreferredSize(new Dimension(410, 88));			
	}
	
/**
 * It create a component before its inclusion in the gui
 */
	private void initResultTitle() 
	{
		this.resultTitle = new JLabel();
		resultTitle.setName("resultTitle");
		resultTitle.setToolTipText(null);
		resultTitle.setText("The Installation test's result");
		resultTitle.setFont(new Font("dialog.bold", Font.BOLD, 12));
		resultTitle.setForeground(new Color(0, 0, 0, 255));
		resultTitle.setEnabled(true);
		resultTitle.setVerticalAlignment(JLabel.CENTER);
		resultTitle.setHorizontalAlignment(JLabel.LEADING);
		resultTitle.setVerticalTextPosition(JLabel.CENTER);
		resultTitle.setHorizontalTextPosition(JLabel.TRAILING);
		resultTitle.setRequestFocusEnabled(true);
		resultTitle.setMinimumSize(null);
		resultTitle.setMaximumSize(new Dimension(2147483647, 2147483647));
		resultTitle.setPreferredSize(new Dimension(163, 18));
	}
	
/**
 * It create a component before its inclusion in the gui
 */
	private void initResult() 
	{
		this.result = new JTextArea();
		result.setName("result");
		result.setToolTipText(null);
		result.setText("Not yet executed ...");
		result.setDragEnabled(false);
		result.setLineWrap(false);
		result.setWrapStyleWord(false);
		result.setEnabled(true);
		result.setColumns(0);
		result.setRows(0);
		result.setTabSize(8);
		result.setRequestFocusEnabled(true);
		result.setMinimumSize(new Dimension(20, 20));
		result.setMaximumSize(null);
		result.setPreferredSize(new Dimension(410, 53));
	}
	
/**
 * It create a component before its inclusion in the gui
 */
	private void initBExit() 
	{
		this.bExit = new JButton();
		bExit.setName("bExit");
		bExit.setToolTipText(null);
		bExit.setText("Exit");
		bExit.setEnabled(true);
		bExit.setSelected(false);
		bExit.setVerticalAlignment(AbstractButton.CENTER);
		bExit.setHorizontalAlignment(AbstractButton.CENTER);
		bExit.setVerticalTextPosition(AbstractButton.CENTER);
		bExit.setHorizontalTextPosition(AbstractButton.TRAILING);
		bExit.setIconTextGap(4);
		bExit.setRequestFocusEnabled(true);
		bExit.setMinimumSize(null);
		bExit.setMaximumSize(new Dimension(2147483647, 2147483647));
		bExit.setPreferredSize(new Dimension(74, 31));
		bExit.setDefaultCapable(true);
		bExit.setBackground(Color.orange);
		
		bExit.addActionListener(new Exit());
	}
	
/**
 * It create a component before its inclusion in the gui
 */
	private void initBStart() 
	{
		this.bStart = new JButton();
		bStart.setName("bStart");
		bStart.setToolTipText(null);
		bStart.setText("Start");
		bStart.setEnabled(true);
		bStart.setSelected(false);
		bStart.setVerticalAlignment(AbstractButton.CENTER);
		bStart.setHorizontalAlignment(AbstractButton.CENTER);
		bStart.setVerticalTextPosition(AbstractButton.CENTER);
		bStart.setHorizontalTextPosition(AbstractButton.TRAILING);
		bStart.setIconTextGap(4);
		bStart.setRequestFocusEnabled(true);
		bStart.setMinimumSize(null);
		bStart.setMaximumSize(new Dimension(2147483647, 2147483647));
		bStart.setPreferredSize(new Dimension(74, 31));
		bStart.setDefaultCapable(true);	
		bStart.setBackground(Color.pink);	
		
		bStart.addActionListener(new Start(this));
	}
	
/**
 * It reads the values in the form and return a vector
 * to the action listener
 */
	public Vector returnFormValue()
	{
	// get fields
		Vector values = new Vector();
		String tmpStr = new String();
		tmpStr = field1.getText();
		values.addElement(tmpStr);
		tmpStr = field2.getText();
		values.addElement(tmpStr);		
		tmpStr = field3.getText();
		values.addElement(tmpStr);
		tmpStr = field4.getText();
		values.addElement(tmpStr);
		
	// get the list of files
		Component comp = listOfFiles.getComponent(0);
		JViewport vp = (JViewport)comp;
		comp = vp.getComponent(0);		
		JTextArea txtList = (JTextArea)comp;
		tmpStr = txtList.getText();
		values.addElement(tmpStr);
		return values;
	}
	
/**
 * Update the result text area with a general message
 */
	public void writeMessage(String msg)
	{
		result.setText(msg);
		result.setFont(new Font("Verdana Grassetto", Font.PLAIN, 11));
		result.setForeground(Color.red);
		repaint();		
	}	

/**
 * Update the result text area with a specific result
 */	
	public void writeResult(String msg)
	{
		result.setFont(new Font("Verdana Grassetto", Font.BOLD, 12));
		result.setText(msg);
		result.setForeground(Color.blue);
		repaint();		
	}	
	
/**
 * In this method on provide to charge a vector
 * with the lines read from file of test TXT.
 *
 * IN: name of file .txt
 * OUT: vector with the values readed (string)
 */
	public Vector readFileTXT(String nameF)
	{
		Vector textRead = new Vector();
		File tmp = new File(TestGUI.dirFile + nameF);
		if (!tmp.canRead() || !tmp.exists())
		{
			writeMessage("ERROR ON OPEN FILE \"" + nameF + "\"");			
		}
		else
		{
			try
			{			
				FileInputStream testList = new FileInputStream(tmp);
				DataInputStream testListIn = new DataInputStream(testList);				
				String testName = testListIn.readLine();		
				while (testName != null)
				{		
					textRead.addElement(testName);
					testName = testListIn.readLine();
				}		
				testListIn.close();		
				testList.close();				
			}
			catch (IOException e)
			{
				writeMessage("I/O ERROR ON READING \"" + nameF + "\"");				
			}
		}						
		return (textRead);
	}

/**
 * Main
 */ 
 	public static void main(String[] args)
 	{
 		JFrame f = new JFrame("Orbilio's Installation Test"); 		
 		JPanel j = new TestGUI();
 		
 		f.addWindowListener
 		(
 			new WindowAdapter()
 			{
 				public void windowClosing(WindowEvent we)
 				{
 					System.exit(0);
 				}  				
 			}
 		);
 		
 		f.setVisible(true); 			
 		f.getContentPane().add (j, BorderLayout.CENTER);
    	f.setSize (570, 400);    	   
    	f.show();
    }
}
